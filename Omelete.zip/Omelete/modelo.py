from datetime import *
now = datetime.now()
class Pessoa:
	def __init__(self, login, senha, nome, tipo="leitor", id=0):
		self.login = login
		self.senha = senha
		self.nome = nome
		self.tipo = tipo
		self.id = id
	def __repr__(self):
		return str(self.id) +";"+ self.login +";"+ self.senha +";"+ self.nome +";"+ self.tipo +";"+"\n"
class Assunto:
	def __init__(self, nome, id=0):
		self.nome = nome
		self.id = id
	def __repr__(self):
		return str(self.id) +";"+ self.nome +";"+"\n"
class Noticia:
	def __init__(self, idassunto, titulo, texto, datapublicacao=str(now.year) + "/" + str(now.month) + "/" + str(now.day), vet=[], id=0):

		self.idassunto = idassunto
		self.titulo = titulo
		self.texto = texto
		self.datapublicacao = datapublicacao
		self.vet = vet
		self.id = id
	def __repr__(self):
		return str(self.id) +";"+ str(self.idassunto) +";"+ self.titulo +";"+ self.texto +";"+ self.datapublicacao +";"+"\n"
class Comentario:
	def __init__(self, idnoticia, pessoa, texto, datacomentario=str(now.year) + "/" + str(now.month) + "/" + str(now.day), id=0):
		
		self.idnoticia = idnoticia
		self.pessoa = pessoa
		self.texto = texto
		self.datacomentario =datacomentario
		self.id = id
	def __repr__(self):
		return str(self.id) +";"+ str(self.idnoticia) +";"+ str(self.idpessoa) +";"+ self.texto +";"+ self.datacomentario +";"+"\n"