DROP TABLE IF EXISTS comentarios;
DROP TABLE IF EXISTS usuarios;
DROP TABLE IF EXISTS noticias;
DROP TABLE IF EXISTS assuntos;

CREATE TABLE assuntos (
    cod SERIAL PRIMARY KEY,
    nome VARCHAR(128) NOT NULL,
    cor CHAR(6) DEFAULT 'FFFFFF'
);
CREATE TABLE noticias (
    cod SERIAL PRIMARY KEY,
    titulo VARCHAR(256) UNIQUE NOT NULL,
    texto TEXT NOT NULL,
    data DATE DEFAULT current_date,
    assunto INTEGER REFERENCES assuntos(cod)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);
CREATE TABLE usuarios (
    login VARCHAR(128) PRIMARY KEY,
    senha CHAR(64) NOT NULL,
    nome VARCHAR(128),
    tipo SMALLINT CHECK (tipo BETWEEN 0 AND 2)
    -- 0: leitor; 1: jornalista; 2: super
);
CREATE TABLE comentarios (
    cod SERIAL PRIMARY KEY,
    noticia INTEGER NOT NULL REFERENCES noticias(cod)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    texto TEXT NOT NULL,
    autor VARCHAR(128) REFERENCES usuarios(login)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    data DATE DEFAULT current_date
)

-- Exs de assuntos

insert into assuntos(nome, cor) values ('Cinema', '7827db')
insert into assuntos(nome, cor) values ('Games', 'd8431e')
insert into assuntos(nome, cor) values ('Música', '24e5b8')

-- ADM porque precisa ter algum

insert into usuarios(login, senha, nome, tipo) values ('davi', '94b8a12fcfd806be7d27fc6a66da0e749e9f06b76ad5adaebada0f593ee9a038', 'Davi', 2) -- Senha: admin777fazSol