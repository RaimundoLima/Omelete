//navbar hover bunitinho
$('.tab a').hover(function () {
    let cor = $(this).attr('data-cor');
    $(this).attr('style', 'color: ' + cor + ' !important; border-color: ' + cor);
}, function () {
    $(this).css('color', 'white');
});

//guarda o valor do nome no form de cadastro pra preencher ele caso dê pau                            <
$('form').submit(() => {
    $('.cache').each(function () {
        sessionStorage[$(this).attr('id')] = $(this).val();
    });
})

$(document).ready(() => {
    //Materialize inicializações
    $('.dropdown-trigger').dropdown({
        coverTrigger: false,
        constrainWidth: false
    });
    $('.fixed-action-btn').floatingActionButton();
    $('.tooltipped').tooltip();

    //verifica se a pagina foi carregada com uma mensagem de pau e coloca o valor do nome no lugar (vide acima)
    if ($('.error')[0]) {
        $('.cache').each(function () {
            if (sessionStorage.getItem($(this).attr('id'))) {
                $(this).val(sessionStorage.getItem($(this).attr('id')));
            }
            //console.log(key + '=>' + sessionStorage.getItem(key));
        });
        M.updateTextFields();
    }

    //passei uma fome pra fazer isso pq n tem como por !important por .css()
    $('.tab a, .noticia').css('border-color', function () {
        let cor = $(this).attr('data-cor')
        return $(this).attr('data-cor');
    });

    // Moving Letters - http://tobiasahlin.com/moving-letters/#9

    // Wrap every letter in a span
    $('.ml9 .letters').each(function () {
        $(this).html($(this).text().replace(/([^\x00-\x80]|\w)/g, "<span class='letter'>$&</span>"));
    });

    anime.timeline({ loop: false })
        .add({
            targets: '.ml9 .letter',
            scale: [0, 1],
            duration: 1500,
            elasticity: 600,
            delay: function (el, i) {
                return 45 * (i + 1)
            }
        })/*.add({
      targets: '.ml9',
      opacity: 0,
      duration: 1000,
      easing: "easeOutExpo",
      delay: 1000
    })*/;

    //
    sessionStorage.clear();
})