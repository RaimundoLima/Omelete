from datetime import date

class Assunto(object):
    def __init__(self, nome="", cor="FFFFFF", cod=0):
        self.cod = cod
        self.nome = nome
        self.cor = cor

class Noticia(object):
    def __init__(self, titulo="", texto="", data=date.today(), assunto=None, cod=0, comentarios=[]):
        self.cod = cod
        self.titulo = titulo
        self.texto = texto
        self.data = data
        self.assunto = assunto
        self.comentarios = comentarios

class Usuario(object):
    def __init__(self, login="", senha="", nome="", tipo=0):
        self.login = login
        self.senha = senha
        self.nome = nome
        self.tipo = tipo

class Comentario(object):
    def __init__(self, noticia=None, texto="", autor=None, data=date.today(), cod=0):
        self.noticia = noticia
        self.texto = texto
        self.autor = autor
        self.data = data
