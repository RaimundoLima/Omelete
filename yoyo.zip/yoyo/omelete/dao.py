from datetime import date
from mod import *
import psycopg2

class AssuntoDAO(object):
    def __init__(self, con):
        self.con = con

    def add(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        try:
            cur.execute('''INSERT INTO assuntos
                            (nome, cor)
                        VALUES
                            (%s, %s)''',
                        (obj.nome, obj.cor))
            con.commit()

            cur.close()
            con.close()

        except psycopg2.IntegrityError:
            return False

        return True

    def get(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        cur.execute("SELECT * FROM assuntos WHERE cod=%s",
                    (obj.cod, ))
        obj2 = cur.fetchone()

        cur.close()
        con.close()

        return Assunto(obj2[1], obj2[2], obj2[0])

    def listall(self):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        objs = []

        cur.execute("SELECT * FROM assuntos")
        for obj in cur:
            objs.append(Assunto(obj[1], obj[2], obj[0]))

        cur.close()
        con.close()

        return objs

    def atualizar(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        cur.execute(''' UPDATE assuntos SET 
                            nome=%s, cor=%s
                        WHERE cod=%s
                    ''',
                    (obj.nome, obj.cor, obj.cod))
        con.commit()

        cur.close()
        con.close()

    def deletar(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        cur.execute("DELETE FROM assuntos WHERE cod=%s", (obj.cod, ))
        con.commit()

        cur.close()
        con.close()

class UsuarioDAO(object):
    def __init__(self, con):
        self.con = con

    def add(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        try:
            cur.execute('''INSERT INTO usuarios
                            (login, senha, nome, tipo)
                        VALUES
                            (%s, %s, %s, %s)''',
                        (obj.login, obj.senha, obj.nome, obj.tipo))
            con.commit()

            cur.close()
            con.close()

        except psycopg2.IntegrityError:
            return False

        return True

    def get(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        cur.execute("SELECT * FROM usuarios WHERE login=%s",
                    (obj.login, ))
        obj2 = cur.fetchone()

        cur.close()
        con.close()

        if(obj2):
            return Usuario(obj2[0], obj2[1], obj2[2], obj2[3])
        else:
            return None

    def listall(self):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        objs = []

        cur.execute("SELECT * FROM usuarios")
        for obj in cur:
            objs.append(Usuario(obj[0], obj[1], obj[2], obj[3]))

        cur.close()
        con.close()

        return objs

    def atualizar(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        cur.execute(''' UPDATE usuarios SET 
                            senha=%s, nome=%s, tipo=%s
                        WHERE login=%s
                    ''',
                    (obj.senha, obj.nome, obj.tipo, obj.login))
        con.commit()

        cur.close()
        con.close()

    def deletar(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        cur.execute("DELETE FROM usuarios WHERE login=%s", (obj.login, ))
        con.commit()

        cur.close()
        con.close()

class NoticiaDAO(object):
    def __init__(self, con):
        self.con = con
        self.adao = AssuntoDAO(con)

    def add(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        try:
            cur.execute('''INSERT INTO noticias
                            (titulo, texto, data, assunto)
                        VALUES
                            (%s, %s, %s, %s)''',
                        (obj.titulo, obj.texto, obj.data, obj.assunto.cod))
            con.commit()

            cur.close()
            con.close()

        except psycopg2.IntegrityError:
            return False

        return True

    def get(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        cur.execute("SELECT * FROM noticias WHERE cod=%s",
                    (obj.cod, ))
        obj2 = cur.fetchone()

        noticia = Noticia(obj2[1], obj2[2], obj2[3], self.adao.get(Assunto(cod=obj2[4])), obj2[0])

        cur.execute("SELECT * FROM comentarios WHERE noticia=%s",
                    (obj.cod, ))
        
        comentarios = []

        for obj3 in cur:
            comentarios.append(Comentario(obj3[1], obj3[2], obj3[3], obj3[4], obj3[0]))

        noticia.comentarios = comentarios

        cur.close()
        con.close()

        return noticia

    def listall(self):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        objs = []

        cur.execute("SELECT * FROM noticias")
        for obj in cur:
            noticia = Noticia(obj[1], obj[2], obj[3], self.adao.get(Assunto(cod=obj[4])), obj[0])

            cur2 = con.cursor()
            cur2.execute("SELECT * FROM comentarios WHERE noticia=%s",
                        (obj[0], ))

            comentarios = []

            for obj2 in cur2:
                comentarios.append(Comentario(obj2[1], obj2[2], obj2[3], obj2[4], obj2[0]))        
                
            noticia.comentarios = comentarios

            objs.append(noticia)
            cur2.close()

        cur.close()
        con.close()

        return objs

    def atualizar(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        cur.execute(''' UPDATE noticias SET 
                            titulo=%s, texto=%s, data=%s, assunto=%s
                        WHERE cod=%s
                    ''',
                    (obj.titulo, obj.texto, obj.data, obj.assunto, obj.cod))
        con.commit()

        cur.close()
        con.close()

    def deletar(self, obj):
        con = psycopg2.connect(self.con)
        cur = con.cursor()

        cur.execute("DELETE FROM noticias WHERE cod=%s", (obj.cod, ))
        con.commit()

        cur.close()
        con.close()
