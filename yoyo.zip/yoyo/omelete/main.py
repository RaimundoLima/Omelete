# -*- coding: utf-8 -*-
from flask import Flask
from flask import render_template, request
from flask import abort, redirect, url_for
from flask import flash, session
from datetime import date
from mod import *
from dao import *
import hashlib

# Esse aqui nao eh responsivo xd

app = Flask(__name__)
app.secret_key = b"s-'k8{/j>D-?qg>"

con = "dbname=omelete host=localhost user=postgres password=postgres"
adao = AssuntoDAO(con)
ndao = NoticiaDAO(con)
udao = UsuarioDAO(con)

@app.route('/')
@app.route('/home')
@app.route('/home/<int:assunto>')
def index(assunto=0):
    if assunto == 0:
        #flash(u'Cadastrado com sucesso! ☺', 'success')
        #flash(u'Ih alá deu pau... ☹', 'error')
        return render_template("index.htm", assuntos=adao.listall(), noticias=ndao.listall(), assunto_filtro=0)
    else:
        noticias_filtradas = []
        for noticia in ndao.listall():
            if noticia.assunto.cod == assunto:
                noticias_filtradas.append(noticia)
        return render_template("index.htm", assuntos=adao.listall(), noticias=noticias_filtradas, assunto_filtro=assunto)


@app.route('/noticia/<int:cod>')
def noticia_view(cod):
    return render_template("noticia.htm", assuntos=adao.listall(), noticia=ndao.get(Noticia(cod=cod)))

@app.route('/cadastro')
def cadastro_form():
    return render_template("cadastro.htm", assuntos=adao.listall())

@app.route('/cadastro/_vai', methods=["POST"])
def cadastro():
    new_usuario = Usuario()
    if(not 'tipo' in request.form):
        new_usuario.tipo = 0
    new_usuario.login = request.form['login']
    new_usuario.nome = request.form['nome']

    #https://blog.codinghorror.com/youre-probably-storing-passwords-incorrectly/
    #descobri aquilo ^ no meio do bagulho e n tive vontade de ajeitar
    #"Hashes alone are better than plain text, but barely."
    new_usuario.senha = hashlib.sha256(request.form['senha']).hexdigest()

    if(udao.add(new_usuario)):
        flash(u'Cadastrado com sucesso! ☺', 'success')
        return redirect(url_for('index'))
    else:
        flash(u'Login já existe... ☹', 'error')
        return redirect(url_for('cadastro_form'))

@app.route('/login')
def login_form():
    return render_template("login.htm", assuntos=adao.listall())

@app.route('/login/_vai', methods=["POST"])
def login():
    usuario = udao.get(Usuario(login=request.form['login']))
    
    if usuario:
        if hashlib.sha256(request.form['senha']).hexdigest() == usuario.senha:
            session['user_login'] = usuario.login
            session['user_nome'] = usuario.nome
            session['user_tipo'] = usuario.tipo
            flash(u'Logado com sucesso! ☺\nOlá %s!'%session['user_nome'], 'success')
            return redirect(url_for('index'))
        else:
            flash(u'Senha não confere ☹', 'error')
            return redirect(url_for('login_form'))
    else:
        flash(u'Usuário não existe ☹', 'error')
        return redirect(url_for('login_form'))

@app.route('/deslogar')
def deslogar():
    session.pop('user_login', None)
    session.pop('user_nome', None)
    session.pop('user_tipo', None)
    flash(u'Deslogado com sucesso! ☺', 'success')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)