import psycopg2
from modelo import *
class Conexao:
	def abrir(self):
		self.conexao = psycopg2.connect("dbname=Trab2Ds2 user=postgres password=postgres host=localhost port=5433")
		self.cursor = self.conexao.cursor()

	def encerrar(self):
		self.conexao.close()
		self.cursor.close()
		
class PessoaDAO:
	def adicionar(self, pessoa):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("insert into aluno (login, senha, nome, tipo) values(%s, %s, %s, %s)", [pessoa.login, pessoa.senha, pessoa.nome, pessoa.tipo])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()

	def listar(self):
		conexao = Conexao()
		conexao.abrir()
		conexao.cursor.execute("select * from pessoa")
		vet = conexao.cursor.fetchall()
		conexao.encerrar()
		vetPessoa = []
		for a in vet:
			vetPessoa.append(Pessoa(a[1],a[2],a[3],a[4],a[0]))
		return vetPessoa

	def obter(self, id):
		conexao = Conexao()
		conexao.abrir()
		conexao.cursor.execute("select * from pessoa where id=%s ", [id])
		vet = conexao.cursor.fetchone()
		conexao.encerrar()
		pessoaObj = []
		pessoaObj.append(Pessoa(vet[1],vet[2],vet[3],vet[4],vet[0]))
		return pessoaObj
	def login(self, login, senha):
		conexao = Conexao()
		conexao.abrir()
		pessoaobj = []
		conexao.cursor.execute("select * from pessoa where login=%s and senha=%s", [login, senha])
		vet = conexao.cursor.fetchone()
		conexao.encerrar()
		pessoaobj.append(Pessoa(vet[1],vet[2],vet[3],vet[4],vet[0]))
		return pessoaobj
	def alterar(self, pessoa):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("update pessoa set login=%s, senha=%s, nome=%s, tipo=%s where id=%s", [pessoa.login, pessoa.senha, pessoa.nome, pessoa.tipo, pessoa.id])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()

	def excluir(self, id):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("delete from pessoa where id=%s", [id])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()
class AssuntoDAO:
	def adicionar(self, assunto):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("insert into aluno (nome) values(%s)", [pessoa.nome])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()

	def listar(self):
		conexao = Conexao()
		conexao.abrir()
		conexao.cursor.execute("select * from assunto")
		vet = conexao.cursor.fetchall()
		conexao.encerrar()
		vetAssunto = []
		for a in vet:
			vetAssunto.append(Assunto(a[1],a[0]))
		return vetAssunto

	def obter(self, id):
		conexao = Conexao()
		conexao.abrir()
		conexao.cursor.execute("select * from assunto where id=%s", [id])
		vet = conexao.cursor.fetchone()
		conexao.encerrar()
		vetAssunto = []
		vetAssunto.append(Assunto(vet[1], vet[0]))
		return vetAssunto

	def alterar(self, assunto):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("update assunto set nome=%s where id=%s", [assunto.nome, assunto.id])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()

	def excluir(self, id):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("delete from assunto where id=%s", [id])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()
class NoticiaDAO:
	def adicionar(self, noticia):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("insert into aluno (idassunto, titulo, texto, datapublicacao) values(%s, %s, %s, %s)", [noticia.assunto.idassunto, noticia.titulo, noticia.texto, noticia.datapublicacao])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()

	def listar(self):
		conexao = Conexao()
		conexao.abrir()
		conexao.cursor.execute("select * from noticia")
		vet = conexao.cursor.fetchall()
		conexao.encerrar()
		vetNoticia = []
		comentarioDAO=ComentarioDAO()
		assuntoDAO=AssuntoDAO()
		for a in vet:
			vetNoticia.append(Noticia(assuntoDAO.obter(a[1]),a[2],a[3],a[4],comentarioDAO.listarComentario(a[0]), a[0]))
		return vetNoticia

	def obter(self, id):
		conexao = Conexao()
		conexao.abrir()
		conexao.cursor.execute("select * from noticia where id=%s", [id])
		vet = conexao.cursor.fetchone()
		conexao.encerrar()
		vetNoticia = []
		comentarioDAO = ComentarioDAO()
		assuntoDAO = AssuntoDAO()
		vetNoticia.append(Noticia(assuntoDAO.obter(vet[1]),vet[2],vet[3],vet[4],comentarioDAO.listarComentario(vet[0]), vet[0]))
		return vetNoticia
	def alterar(self, noticia):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("update noticia set idassunto=%s, titulo=%s, texto=%s, datapublicacao=%s where id=%s", [noticia.assunto.id, noticia.titulo, noticia.texto, noticia.datapublicacao, aluno.id])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()

	def excluir(self, id):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("delete from noticia where id=%s", [id])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()
class ComentarioDAO:
	def adicionar(self, comentario):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("insert into comentario (idnoticia, idpessoa, texto, datacomentario) values(%s, %s, %s, %s)", [comentario.noticia.id, comentario.pessoa.idpessoa, comentario.texto, comentario.datacomentario])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()

	def listar(self):
		conexao = Conexao()
		conexao.abrir()
		conexao.cursor.execute("select * from comentario")
		vet = conexao.cursor.fetchall()
		conexao.encerrar()
		vetComentario = []
		pessoaDAO = PessoaDAO()
		noticiaDAO = NoticiaDAO()
		for a in vet:
			vetComentario.append(Comentario(noticiaDAO.obter(a[1]),pessoaDAO.obter(a[2]),a[3],a[4],a[0]))
		return vetComentario

	def listarComentario(self, idNoticia):
		conexao = Conexao()
		conexao.abrir()
		conexao.cursor.execute("select * from comentario where idnoticia=%s", [idNoticia])
		vet = conexao.cursor.fetchall()
		conexao.encerrar()
		vetComentario = []
		pessoaDAO = PessoaDAO()
		noticiaDAO = NoticiaDAO()
		for a in vet:
			vetComentario.append(Comentario(noticiaDAO.obter(a[1]),pessoaDAO.obter(a[2]),a[3],a[4],a[0]))
		return vetComentario

	def obter(self, id):
		conexao = Conexao()
		conexao.abrir()
		conexao.cursor.execute("select * from comentario where id=%s", [id])
		vet = conexao.cursor.fetchone()
		conexao.encerrar()
		vetComentario = []
		pessoaDAO = PessoaDAO()
		noticiaDAO = NoticiaDAO()
		vetComentario.append(Comentario(noticiaDAO.obter(vet[1]),pessoaDAO.obter(vet[2]),vet[3],vet[4],vet[0]))
		return vetComentario
	def alterar(self, comentario):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("update comentario set idnoticia=%s, idpessoa=%s, texto=%s, datacomentario=%s where id=%s", [comentario.idnoticia, comentario.idpessoa, comentario.texto, comentario.datacomentario, comentario.id])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()

	def excluir(self, id):
		conexaoObj = Conexao()
		conexaoObj.abrir()
		conexaoObj.cursor.execute("delete from comentario where id=%s", [id])
		conexaoObj.conexao.commit()
		conexaoObj.encerrar()