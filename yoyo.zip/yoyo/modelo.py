from datetime import *
now = datetime.now()
class Pessoa:
	def __init__(self, login, senha, nome, tipo="leitor", id=0):
		self.login = login
		self.senha = senha
		self.nome = nome
		self.tipo = tipo
		self.id = id
	def __repr__(self):
		return str(self.id) +";"+ self.login +";"+ self.senha +";"+ self.nome +";"+ self.tipo +";"+"\n"
class Assunto:
	def __init__(self, nome, id=0):
		self.nome = nome
		self.id = id
	def __repr__(self):
		return str(self.id) +";"+ self.nome +";"+"\n"
class Noticia:
	def __init__(self, assunto, titulo, texto, datapublicacao=str(now.year) + "/" + str(now.month) + "/" + str(now.day), comentarios=[], id=0):

		self.assunto = assunto
		self.titulo = titulo
		self.texto = texto
		self.datapublicacao = datapublicacao
		self.comentarios = comentarios
		self.id = id
	def __repr__(self):
		return str(self.id) +";"+ str(self.idassunto) +";"+ self.titulo +";"+ self.texto +";"+ self.datapublicacao +";"+"\n"
class Comentario:
	def __init__(self, noticia, pessoa, texto, datacomentario=str(now.year) + "/" + str(now.month) + "/" + str(now.day), id=0):
		
		self.noticia = noticia
		self.pessoa = pessoa
		self.texto = texto
		self.datacomentario =datacomentario
		self.id = id
	def __repr__(self):
		return str(self.id) +";"+ str(self.idnoticia) +";"+ str(self.idpessoa) +";"+ self.texto +";"+ self.datacomentario +";"+"\n"